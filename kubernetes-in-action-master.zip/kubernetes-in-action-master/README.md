# Kubernetes in action

This repository contains all the code (and some additional files) from my [Kubernetes in Action](http://manning.com/books/kubernetes-in-action?) book.

The files for the [second edition](http://kubernetes-in-action.com/second-edition) of the book are in a [different repository](http://github.com/luksa/kubernetes-in-action-2nd-edition).
