
kubectl expose deployment kubia --port=80 --target-port=8080

